# Pickcolors
Desktop app to run offline, persistent desktop apps in JavaScript using Electron, React, and local JSON storage.

The project uses [electron-json-storage](https://github.com/electron-userland/electron-json-storage) to persist basic data structures in JSON.

This repo is an extension of [basic-electron-react-boilerplate](https://github.com/keithweaver/basic-electron-react-boilerplate)
The following comes from that repo:

## Modern and Minimal Electron + React Starter Kit

_Electron, React, Webpack -- Modern and up-to-date, with a handful of quality of life features included_

### To get started:
* Run `npm install`

##### Development
* Run `npm run dev` to start webpack-dev-server. Electron will launch automatically after compilation.

##### Production
_You have two options, an automatic build or two manual steps_

###### One Shot
* Run `npm run package` to have webpack compile your application into `dist/bundle.js` and `dist/index.html`, and then an electron-packager run will be triggered for the current platform/arch, outputting to `builds/`

###### Manual
_Recommendation: Update the "postpackage" script call in package.json to specify parameters as you choose and use the `npm run package` command instead of running these steps manually_
* Run `npm run build` to have webpack compile and output your bundle to `dist/bundle.js`
* Then you can call electron-packager directly with any commands you choose

If you want to test the production build (In case you think Babili might be breaking something) after running `npm run build` you can then call `npm run prod`. This will cause electron to load off of the `dist/` build instead of looking for the webpack-dev-server instance. Electron will launch automatically after compilation.

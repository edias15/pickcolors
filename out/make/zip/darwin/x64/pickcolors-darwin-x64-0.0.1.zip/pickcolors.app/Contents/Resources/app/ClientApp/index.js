import React from 'react';
import { render } from 'react-dom';
import App from './containers/App';

// Now we can render our application into it
render( <App />, document.getElementById('app') );

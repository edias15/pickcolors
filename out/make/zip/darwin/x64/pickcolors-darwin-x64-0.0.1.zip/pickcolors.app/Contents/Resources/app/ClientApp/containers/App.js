import React, { Component } from 'react';
import Routes from '../components/routes/Routes';

class App extends Component {
  render() {
    return (
      <div>
        <Routes />
      </div>
    );
  }
}

export default App;

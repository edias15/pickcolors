import React, { Component } from 'react';
import Pickcolors from '../components/pickcolors/Pickcolors';

class App extends Component {
  render() {
    return (
      <div>
        <Pickcolors />
      </div>
    );
  }
}

export default App;

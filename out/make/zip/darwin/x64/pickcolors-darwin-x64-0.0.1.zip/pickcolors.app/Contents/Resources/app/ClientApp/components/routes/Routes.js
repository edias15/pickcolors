import React, {useEffect} from 'react';
import Home from "../home/Home"

const Routes = () => {

  return (
    <div>
      <h3>Pickcolors</h3>
      <Home />
    </div>
  )
};

export default Routes;

